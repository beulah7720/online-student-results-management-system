package screens;

import javax.swing.*;
import java.sql.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AdminLogin extends JFrame {

    JTextField txtUser;
    JPasswordField txtPass;

    public AdminLogin() {

        setTitle("Admin Login");
        setSize(300, 220);
        setLayout(null);
        setLocationRelativeTo(null);

        

        JLabel u = new JLabel("Username:");
        JLabel p = new JLabel("Password:");

        txtUser = new JTextField();
        txtPass = new JPasswordField();

        JButton btn = new JButton("Login");

        u.setBounds(40, 40, 100, 25);
        txtUser.setBounds(140, 40, 120, 25);

        p.setBounds(40, 80, 100, 25);
        txtPass.setBounds(140, 80, 120, 25);

        btn.setBounds(100, 130, 80, 30);

        add(u); add(txtUser);
        add(p); add(txtPass);
        add(btn);

        btn.addActionListener(e -> login());

        // ❌ DO NOT EXIT APPLICATION
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        // ✅ X press cheste MainLogin ki vellali
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new MainLogin();   // back to main login
                dispose();        // close current window
            }
        });
        setVisible(true);
    }

    private void login() {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM admin WHERE username=? AND password=?");

            ps.setString(1, txtUser.getText());
            ps.setString(2, new String(txtPass.getPassword()));

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Session.role = "ADMIN";
                new AdminDashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Admin Login");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ MAIN METHOD
    public static void main(String[] args) {
        new AdminLogin();
    }
}