package screens;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AdminDashboard extends JFrame {

    public AdminDashboard() {

        setTitle("Admin Dashboard");
        setSize(300, 300);
        setLayout(null);
        setLocationRelativeTo(null);

        JButton b1 = new JButton("Add Student");
        JButton b2 = new JButton("Add Result");
        JButton b3 = new JButton("View Result");
        JButton b4 = new JButton("Logout");

        b1.setBounds(70, 40, 150, 30);
        b2.setBounds(70, 80, 150, 30);
        b3.setBounds(70, 120, 150, 30);
        b4.setBounds(70, 160, 150, 30);

        add(b1); 
        add(b2); 
        add(b3); 
        add(b4);

        b1.addActionListener(e -> new AddStudent());
        b2.addActionListener(e -> new AddResult());
        b3.addActionListener(e -> new ViewResultAdmin());
        b4.addActionListener(e -> {
            Session.role = null;
            new MainLogin();
            dispose();
        });

         // ❌ DO NOT EXIT APPLICATION
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        // ✅ X press cheste MainLogin ki vellali
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new MainLogin();   // back to main login
                dispose();        // close current window
            }
        });
        setVisible(true);
    }

    // ✅ MAIN METHOD
    public static void main(String[] args) {
        // testing purpose
        Session.role = "ADMIN";
        new AdminDashboard();
    }
}