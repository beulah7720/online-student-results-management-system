package screens;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ViewResultStudent extends JFrame {

    JTable table;
    JLabel lblSGPA, lblCGPA;
    JComboBox<Integer> cbSem;
    DefaultTableModel model;

    public ViewResultStudent() {

        setTitle("My Result");
        setSize(650,450);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblSem = new JLabel("Semester:");
        lblSem.setBounds(200,20,80,25);

        cbSem = new JComboBox<>();
        for(int i=1;i<=8;i++) cbSem.addItem(i);
        cbSem.setBounds(280,20,80,25);

        JButton btnView = new JButton("View");
        btnView.setBounds(380,20,80,25);

        model = new DefaultTableModel(
                new String[]{"Course","Marks","Grade","Credits"},0);

        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(40,70,550,250);

        lblSGPA = new JLabel("SGPA : ");
        lblSGPA.setBounds(150,340,150,25);

        lblCGPA = new JLabel("CGPA : ");
        lblCGPA.setBounds(350,340,150,25);

        add(lblSem); add(cbSem); add(btnView);
        add(sp); add(lblSGPA); add(lblCGPA);

        btnView.addActionListener(e -> loadResult());

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new StudentDashboard();
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadResult() {

        model.setRowCount(0);
        lblSGPA.setText("SGPA : ");
        lblCGPA.setText("CGPA : ");

        String sid = Session.studentId;
        int sem = (int) cbSem.getSelectedItem();

        try {
            Connection con = DBConnection.getConnection();

            // ✅ Fetch subjects with earned credits (pass only)
            PreparedStatement ps = con.prepareStatement(
                "SELECT c.course_name, r.marks, r.grade, " +
                "CASE WHEN r.marks >= 40 THEN c.credits ELSE 0 END AS earned_credits " +
                "FROM results r JOIN courses c ON r.course_id=c.course_id " +
                "WHERE r.student_id=? AND r.semester=?");

            ps.setString(1, sid);
            ps.setInt(2, sem);

            ResultSet rs = ps.executeQuery();

            boolean found = false;

            while(rs.next()){
                found = true;
                model.addRow(new Object[]{
                        rs.getString(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getInt(4)
                });
            }

            if(!found){
                JOptionPane.showMessageDialog(this,"No Results Found");
                return;
            }

            // ✅ SGPA (pass subjects only)
            PreparedStatement sg = con.prepareStatement(
                "SELECT SUM(r.grade_points * " +
                "CASE WHEN r.marks >= 40 THEN c.credits ELSE 0 END) / " +
                "SUM(CASE WHEN r.marks >= 40 THEN c.credits ELSE 0 END) " +
                "FROM results r JOIN courses c ON r.course_id=c.course_id " +
                "WHERE r.student_id=? AND r.semester=?");

            sg.setString(1, sid);
            sg.setInt(2, sem);

            ResultSet sgRs = sg.executeQuery();

            if(sgRs.next()) {
                double sgpa = sgRs.getDouble(1);
                if(!sgRs.wasNull())
                    lblSGPA.setText("SGPA : " + String.format("%.2f", sgpa));
                else
                    lblSGPA.setText("SGPA : 0.00");
            }

            // ✅ CGPA (all semesters combined)
            PreparedStatement cg = con.prepareStatement(
                "SELECT SUM(r.grade_points * " +
                "CASE WHEN r.marks >= 40 THEN c.credits ELSE 0 END) / " +
                "SUM(CASE WHEN r.marks >= 40 THEN c.credits ELSE 0 END) " +
                "FROM results r JOIN courses c ON r.course_id=c.course_id " +
                "WHERE r.student_id=?");

            cg.setString(1, sid);

            ResultSet cgRs = cg.executeQuery();

            if(cgRs.next()) {
                double cgpa = cgRs.getDouble(1);
                if(!cgRs.wasNull())
                    lblCGPA.setText("CGPA : " + String.format("%.2f", cgpa));
                else
                    lblCGPA.setText("CGPA : 0.00");
            }

        } catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ViewResultStudent();
        });
    }
}