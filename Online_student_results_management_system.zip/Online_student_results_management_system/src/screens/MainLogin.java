package screens;

import javax.swing.*;

public class MainLogin extends JFrame {

    public MainLogin() {

        setTitle("Login Portal");
        setSize(300, 200);
        setLayout(null);
        setLocationRelativeTo(null);

        JButton btnAdmin = new JButton("Admin Login");
        JButton btnStudent = new JButton("Student Login");

        btnAdmin.setBounds(70, 50, 150, 30);
        btnStudent.setBounds(70, 100, 150, 30);

        add(btnAdmin);
        add(btnStudent);

        btnAdmin.addActionListener(e -> new AdminLogin());
        btnStudent.addActionListener(e -> new StudentLogin());

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    // ✅ MAIN METHOD
    public static void main(String[] args) {
        new MainLogin();
    }
}