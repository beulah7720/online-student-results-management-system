package screens;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.event.*;

public class AddResult extends JFrame {

    JTextField txtStudentId, txtSemester;
    JTable table;
    DefaultTableModel model;
    JButton btnSave, btnClear;

    public AddResult() {

        setTitle("Add Student Result");
        setSize(500, 450);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblTitle = new JLabel("Add Student Result");
        lblTitle.setBounds(170, 20, 200, 25);

        JLabel lblId = new JLabel("Student ID:");
        lblId.setBounds(40, 60, 100, 25);

        txtStudentId = new JTextField();
        txtStudentId.setBounds(150, 60, 200, 25);

        JLabel lblSem = new JLabel("Semester:");
        lblSem.setBounds(40, 100, 100, 25);

        txtSemester = new JTextField();
        txtSemester.setBounds(150, 100, 200, 25);

        // 🔹 Table
        model = new DefaultTableModel();
        model.addColumn("Course Name");
        model.addColumn("Marks");

        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(40, 150, 400, 180);

        btnSave = new JButton("Save");
        btnClear = new JButton("Clear");

        btnSave.setBounds(130, 350, 100, 30);
        btnClear.setBounds(260, 350, 100, 30);

        add(lblTitle);
        add(lblId); add(txtStudentId);
        add(lblSem); add(txtSemester);
        add(sp);
        add(btnSave); add(btnClear);

        // Semester enter chesaka subjects load avvali (Focus lost)
        txtSemester.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                loadSubjects();
            }
        });

        // ✅ Enter key press chesina load avvali
        txtSemester.addActionListener(e -> loadSubjects());
        btnSave.addActionListener(e -> saveResults());
        btnClear.addActionListener(e -> clearFields());

        // ❌ X press cheste AdminDashboard ki vellali
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new AdminDashboard();
                dispose();
            }
        });

        setVisible(true);
    }

    // ================= LOAD SUBJECTS =================
    private void loadSubjects() {

        model.setRowCount(0);

        String studentId = txtStudentId.getText();
        String semText = txtSemester.getText();

        if (studentId.isEmpty() || semText.isEmpty()) return;

        try {
            int semester = Integer.parseInt(semText);
            Connection con = DBConnection.getConnection();

            // check student
            PreparedStatement chk = con.prepareStatement(
                    "SELECT * FROM students WHERE student_id=?");
            chk.setString(1, studentId);
            ResultSet crs = chk.executeQuery();

            if (!crs.next()) {
                JOptionPane.showMessageDialog(this, "Student Not Found");
                return;
            }

            // load courses
            PreparedStatement ps = con.prepareStatement(
                    "SELECT course_name FROM courses WHERE semester=?");
            ps.setInt(1, semester);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{rs.getString(1), ""});
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No subjects for this semester");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ================= SAVE RESULTS =================
    private void saveResults() {

        try {
            String studentId = txtStudentId.getText();
            int semester = Integer.parseInt(txtSemester.getText());

            Connection con = DBConnection.getConnection();

            for (int i = 0; i < model.getRowCount(); i++) {

                String courseName = model.getValueAt(i, 0).toString();
                String marksStr = model.getValueAt(i, 1).toString();

                if (marksStr.isEmpty()) continue;

                int marks = Integer.parseInt(marksStr);

                // get course id
                PreparedStatement cid = con.prepareStatement(
                        "SELECT course_id FROM courses WHERE course_name=?");
                cid.setString(1, courseName);
                ResultSet cr = cid.executeQuery();
                cr.next();
                String courseId = cr.getString(1);

                // duplicate check
                PreparedStatement dup = con.prepareStatement(
                        "SELECT * FROM results WHERE student_id=? AND semester=? AND course_id=?");
                dup.setString(1, studentId);
                dup.setInt(2, semester);
                dup.setString(3, courseId);

                if (dup.executeQuery().next()) continue;

                // grade
                String grade;
                int gp;

                if (marks >= 90) { grade = "O"; gp = 10; }
                else if (marks >= 80) { grade = "A+"; gp = 9; }
                else if (marks >= 70) { grade = "A"; gp = 8; }
                else if (marks >= 60) { grade = "B"; gp = 7; }
                else if (marks >= 50) { grade = "C"; gp = 6; }
                else { grade = "F"; gp = 0; }

                PreparedStatement ins = con.prepareStatement(
                        "INSERT INTO results VALUES (?,?,?,?,?,?)");

                ins.setString(1, studentId);
                ins.setInt(2, semester);
                ins.setString(3, courseId);
                ins.setInt(4, marks);
                ins.setString(5, grade);
                ins.setInt(6, gp);

                ins.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Results Saved Successfully");
            clearFields();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void clearFields() {
        txtStudentId.setText("");
        txtSemester.setText("");
        model.setRowCount(0);
    }   

    // ================= MAIN =================
    public static void main(String[] args) {
        Session.role = "ADMIN";
        new AddResult();
    }
}