package screens;

public class Session {
    public static String studentId = null;
    public static String role = null; // ADMIN or STUDENT
}