package screens;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class ViewResultAdmin extends JFrame {

    JTextField txtStudentId;
    JComboBox<Integer> cbSemester;
    JTable table;
    JLabel lblSGPA, lblCGPA;

    DefaultTableModel model;

    public ViewResultAdmin() {

        setTitle("Admin - View Student Result");
        setSize(750, 520);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblTitle = new JLabel("ADMIN VIEW RESULT");
        lblTitle.setBounds(300, 20, 200, 25);

        JLabel lblId = new JLabel("Student ID:");
        lblId.setBounds(40, 60, 100, 25);

        txtStudentId = new JTextField();
        txtStudentId.setBounds(130, 60, 150, 25);

        JLabel lblSem = new JLabel("Semester:");
        lblSem.setBounds(310, 60, 100, 25);

        cbSemester = new JComboBox<>();
        for (int i = 1; i <= 8; i++) cbSemester.addItem(i);
        cbSemester.setBounds(390, 60, 80, 25);

        JButton btnView = new JButton("View");
        btnView.setBounds(500, 60, 100, 25);

        model = new DefaultTableModel(
                new String[]{"Course Name", "Marks", "Grade", "Credits"}, 0);

        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(40, 110, 650, 280);

        lblSGPA = new JLabel("SGPA : ");
        lblSGPA.setBounds(150, 420, 200, 25);

        lblCGPA = new JLabel("CGPA : ");
        lblCGPA.setBounds(420, 420, 200, 25);

        add(lblTitle);
        add(lblId); add(txtStudentId);
        add(lblSem); add(cbSemester);
        add(btnView);
        add(sp);
        add(lblSGPA);
        add(lblCGPA);

        btnView.addActionListener(e -> loadResult());

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new AdminDashboard();
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadResult() {
        model.setRowCount(0);

        String studentId = txtStudentId.getText();
        int sem = (int) cbSemester.getSelectedItem();

        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Student ID");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT c.course_name, r.marks, r.grade, c.credits " +
                "FROM results r JOIN courses c ON r.course_id=c.course_id " +
                "WHERE r.student_id=? AND r.semester=?"
            );

            ps.setString(1, studentId);
            ps.setInt(2, sem);

            ResultSet rs = ps.executeQuery();
            boolean found = false;

            while (rs.next()) {
                found = true;
                model.addRow(new Object[]{
                        rs.getString(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getInt(4)
                });
            }

            if (!found) {
                JOptionPane.showMessageDialog(this, "No Result Found");
                lblSGPA.setText("SGPA : ");
                lblCGPA.setText("CGPA : ");
                return;
            }

            PreparedStatement sgpaPs = con.prepareStatement(
                "SELECT SUM(r.grade_points*c.credits)/SUM(c.credits) " +
                "FROM results r JOIN courses c ON r.course_id=c.course_id " +
                "WHERE r.student_id=? AND r.semester=?"
            );
            sgpaPs.setString(1, studentId);
            sgpaPs.setInt(2, sem);

            ResultSet sgRs = sgpaPs.executeQuery();
            if (sgRs.next()) {
                lblSGPA.setText("SGPA : " + String.format("%.2f", sgRs.getDouble(1)));
            }

           PreparedStatement cgpaPs = con.prepareStatement(
    "SELECT AVG(sgpa) FROM (" +
    "SELECT SUM(r.grade_points*c.credits)/SUM(c.credits) AS sgpa " +
    "FROM results r JOIN courses c ON r.course_id=c.course_id " +
    "WHERE r.student_id=? GROUP BY r.semester) t"
);
            cgpaPs.setString(1, studentId);

            ResultSet cgRs = cgpaPs.executeQuery();
            if (cgRs.next()) {
                lblCGPA.setText("CGPA : " + String.format("%.2f", cgRs.getDouble(1)));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    // ✅ MAIN METHOD
    public static void main(String[] args) {
        // testing purpose
        Session.role = "ADMIN";
        new ViewResultAdmin();
    }
}