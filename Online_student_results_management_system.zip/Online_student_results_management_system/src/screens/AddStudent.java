package screens;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddStudent extends JFrame {

    JTextField txtId, txtName, txtBranch;
    JButton btnSave, btnClear;

    public AddStudent() {

        setTitle("Add Student");
        setSize(380, 300);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblTitle = new JLabel("Add Student Details");
        lblTitle.setBounds(120, 20, 200, 30);

        JLabel lblId = new JLabel("Roll No:");
        JLabel lblName = new JLabel("Student Name:");
        JLabel lblBranch = new JLabel("Branch:");

        txtId = new JTextField();
        txtName = new JTextField();
        txtBranch = new JTextField();

        btnSave = new JButton("Save");
        btnClear = new JButton("Clear");

        lblId.setBounds(50, 70, 120, 25);
        txtId.setBounds(170, 70, 150, 25);

        lblName.setBounds(50, 110, 120, 25);
        txtName.setBounds(170, 110, 150, 25);

        lblBranch.setBounds(50, 150, 120, 25);
        txtBranch.setBounds(170, 150, 150, 25);

        btnSave.setBounds(90, 200, 90, 30);
        btnClear.setBounds(200, 200, 90, 30);

        add(lblTitle);
        add(lblId); add(txtId);
        add(lblName); add(txtName);
        add(lblBranch); add(txtBranch);
        add(btnSave); add(btnClear);

        btnSave.addActionListener(e -> saveStudent());
        btnClear.addActionListener(e -> clearFields());

        setVisible(true);
    }

    private void saveStudent() {
        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO students(student_id, student_name, branch) VALUES (?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, txtId.getText());
            ps.setString(2, txtName.getText());
            ps.setString(3, txtBranch.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Student Added Successfully");
            clearFields();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding student");
        }
    }

    private void clearFields() {
        txtId.setText("");
        txtName.setText("");
        txtBranch.setText("");
    }

    // ✅ main method
    public static void main(String[] args) {
        new AddStudent();
    }
}