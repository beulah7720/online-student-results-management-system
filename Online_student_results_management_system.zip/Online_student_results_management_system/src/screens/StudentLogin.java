package screens;

import javax.swing.*;
import java.sql.*;
import java.awt.event.*;

public class StudentLogin extends JFrame {

    JTextField txtId;
    JPasswordField txtPass;

    public StudentLogin() {

      

    setTitle("Student Login");
    setSize(350,250);
    setLayout(null);
    setLocationRelativeTo(null);

    // Application close kakudadhu
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

    // X press cheste MainLogin ki vellali
    addWindowListener(new WindowAdapter() {
        @Override
        public void windowClosing(WindowEvent e) {
            new MainLogin();
            dispose();
        }
    });

    setVisible(true);


        JLabel lblId = new JLabel("Student ID:");
        JLabel lblPass = new JLabel("Password:");

        txtId = new JTextField();
        txtPass = new JPasswordField();

        JButton btnLogin = new JButton("Login");

        lblId.setBounds(40,50,100,25);
        txtId.setBounds(150,50,140,25);

        lblPass.setBounds(40,90,100,25);
        txtPass.setBounds(150,90,140,25);

        btnLogin.setBounds(120,140,100,30);

        add(lblId); add(txtId);
        add(lblPass); add(txtPass);
        add(btnLogin);

        btnLogin.addActionListener(e -> login());

        
    }

    private void login() {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM students WHERE student_id=? AND password=?");

            ps.setString(1, txtId.getText());
            ps.setString(2, new String(txtPass.getPassword()));

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Session.role = "STUDENT";
                Session.studentId = txtId.getText();
                new StudentDashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Login");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ✅ main method
    public static void main(String[] args) {
        new StudentLogin();
    }
}