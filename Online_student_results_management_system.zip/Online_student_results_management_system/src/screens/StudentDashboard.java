package screens;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class StudentDashboard extends JFrame {

    public StudentDashboard() {

        setTitle("Student Dashboard");
        setSize(300, 250);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lbl = new JLabel("Welcome : " + Session.studentId);
        lbl.setBounds(80, 30, 200, 25);

        JButton btnView = new JButton("View Result");
        JButton btnLogout = new JButton("Logout");

        btnView.setBounds(80, 80, 140, 30);
        btnLogout.setBounds(80, 130, 140, 30);

        add(lbl);
        add(btnView);
        add(btnLogout);

        btnView.addActionListener(e -> new ViewResultStudent());
        btnLogout.addActionListener(e -> {
            Session.studentId = null;
            new StudentLogin();
            dispose();
        });

         // ❌ DO NOT EXIT APPLICATION
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        // ✅ X press cheste MainLogin ki vellali
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new MainLogin();   // back to main login
                dispose();        // close current window
            }
        });
        setVisible(true);
    }

    // ✅ MAIN METHOD
    public static void main(String[] args) {
        // testing purpose ki
        
        new StudentDashboard();
    }
}