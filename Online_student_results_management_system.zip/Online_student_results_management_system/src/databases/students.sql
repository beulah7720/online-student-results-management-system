CREATE TABLE students (
    student_id VARCHAR(20) PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    branch VARCHAR(50),
    password VARCHAR(50)
);