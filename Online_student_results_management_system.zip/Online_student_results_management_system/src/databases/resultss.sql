CREATE TABLE results (
    student_id VARCHAR(20) NOT NULL,
    semester INT NOT NULL,
    course_id VARCHAR(10) NOT NULL,
    marks INT,
    grade VARCHAR(5),
    grade_points INT,

    PRIMARY KEY (student_id, semester, course_id),

    FOREIGN KEY (student_id) REFERENCES students(student_id)
        ON DELETE CASCADE,

    FOREIGN KEY (course_id) REFERENCES courses(course_id)
        ON DELETE CASCADE
);